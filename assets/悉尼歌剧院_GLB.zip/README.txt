Sydney Opera House — standalone GLB

sydney_opera_house.glb is a glTF2.0 binary with all8 image textures embedded. Fresh import was independently checked. It contains361 meshes /200,252 triangles and a compact188×260m harbour context, not the native file's distant render-water backdrop.

Microtile color and normal maps use metric UV0; the shared matte/glazed lid finish uses roughness UV1. Tile pitch is nominal120mm: the largest spherical patch has approximately109–131mm directional mapping; narrow ruled joins can vary more. Shapes and podium boundaries remain source-fitted, not surveyed construction data.

Geometry follows glTF's Y-up convention. Analytic source-control extras retain Blender's Z-up convention; Blender import restores that coordinate basis. All dimensions are metres.

This is a static exchange model. The packed .blend contains the three complete lighting presets and the20-second orbit camera path. The rendered video is delivered separately. There are no auditorium interiors or collision-enabled walking physics.

SHA-256:
2673b65699cea719da3e9668e0bc468e81a35e910bb646b737a365b267d8a496
