# Florence Cathedral | Original Exterior Reconstruction

An original, metre-scale Blender reconstruction of the permanent exterior of Santa Maria del Fiore, Giotto’s Campanile and the Baptistery of San Giovanni. Created from published dimensions, architectural plans and licensed photographs. No complete third-party 3D model, scan or photogrammetric mesh was imported.

## Open the work

- Native master: `versions/v06_final.blend`, Blender 4.3.2
- Exchange model: `export/Florence_Cathedral_Exterior.glb`, one scene, metres, self-contained materials
- Four 2400 × 1800 hero PNGs and one additional warm-light hero: `renders/heroes/`
- Eight 1600 × 1200 directional inspection PNGs: `renders/checks/`
- Actual rendered 16-second, 18 fps camera orbit: `movie/Florence_Cathedral_Orbit.mp4`
- Research, attribution and uncertainty: `research/sources.md`, `research/reference_manifest.json`, `research/assumptions.md`
- Three source/render correction rounds: `qa/comparison_rounds.md`

## Scope and interpretation

The model covers the exterior cathedral body, three polygonal tribunes, diagonal semicircular blind tribunes, octagonal drum, pointed eight-sail dome, eight exposed marble ribs, lantern, west façade, freestanding campanile, Baptistery and a restrained paved piazza. There is no modeled church interior, crypt, full city or collision system. Current temporary scaffolding and construction logistics are omitted.

Figurative statues, narrative reliefs and narrative mosaics are intentionally omitted. Architectural niches and relief frames remain present and visibly empty. These omissions are preferable to invented or crude substitute figures. Fine stone carving, irregular repairs, weathering and some elevation-specific doorway details are simplified. The principal visible geometry is modeled, including portal recesses, circular windows, Gothic tracery, pier profiles, marble partitions and individual roof tiles; no photographic façade sticker is used.

## Dimensions and uncertainty

The local origin is the centre of the west façade, with +X toward the east end and +Y toward local north. One Blender unit is one metre. Local axes are idealized and differ slightly from geographic cardinal axes.

- Cathedral exterior is approximately 156 m long, 95 m across the tribunes and 43 m across the nave
- Crossing centre is approximately (107, 0) m
- Dome outer diameter is 54.8 m, springing 54.6 m, lantern seat about 90 m and cross top about 116 m
- Campanile centre is (8, −33) m; nominal body about 15 m square; architectural crown 84.7 m. The slender modern lightning conductor extends above this architectural datum
- Baptistery centre is (−45, −1.4) m; exterior vertex diameter about 35 m. Eave 23 m, lantern seat 33 m and total height about 39 m are inferred from a survey elevation with a measured 35 m sensor, not claimed as exact survey heights

Opera publishes cathedral length 153 m and transept 90 m without defining endpoints. A measured historical plan and current 2D mapped perimeter support exterior values around 153–156 m and 95–97 m. The model does not silently treat the official figures as exact exterior endpoints, nor adopt an uncorroborated 166 m length. The Baptistery’s often quoted 25.6 m is an interior span, not its exterior footprint.

The main dome uses an outer quarto-acuto-inspired pointed curve with eight lightly bowed sails, not a sphere. Two separate closed thin-shell meshes and connecting meridian/tie elements make its double-shell arrangement inspectable. Hidden shell thicknesses and internal reinforcement are diagrammatic approximations, not an engineering reconstruction. Only the southeast drum face receives the completed decorative gallery; the others retain the unfinished masonry band.

## Blender scene organization

Both persistent lighting scenes use these nine root collections:

1. `00_REFERENCE` — dimension/reference metadata
2. `01_BLOCKOUT` — hidden archived whitebox, excluded from export
3. `02_STRUCTURE` — main exterior structural components
4. `03_MODULES` — reusable linked ornamental modules
5. `04_DETAILS` — marble inlays, openings, tracery and roof tile geometry
6. `05_MATERIALS` — palette index; actual materials are normal Blender datablocks
7. `06_GROUND` — simplified piazza, paving and scale bollards
8. `07_LIGHTS` — daylight/warm subcollections with per-scene exclusions
9. `08_CAMERAS` — inspection, hero, walk and orbital cameras

`Neutral_Daylight` and `Warm_Late_Afternoon` are persistent scenes, sharing geometry but using distinct worlds and lighting. The six milestone files are immutable snapshots of the process. Earlier stages preserve the evidence of corrections and are not substitutes for the final validated master.

## Walk navigation

Select `Exterior_Walk_Start`, then use the camera-view control or Numpad0. Its eye is exactly1.65 m above the modeled paving surface: groundZ0.015 m, cameraZ1.665 m. In Blender, press Shift+` to start Walk Navigation, use WASD, move the mouse to look, and use the mouse wheel to adjust speed. Confirm with the left mouse button or exit with Esc. Gravity/collision is not enabled; movement can pass through walls. The GLB is a portable exterior model, not a packaged first-person application.

## Parametric source

The `scripts/` directory contains the original generators. `common.py` provides metre-based geometric helpers; `architecture.py` builds the main body, drum, roofs, tribunes and Baptistery; `facade_module.py` and `tower_module.py` generate detailed modular elevations. Linked rose petals and shared tower elevation meshes provide actual reusable geometry. `model_parameters.json` records the dimensional inputs. The final correction, rendering, export and movie scripts are retained for reproducibility.

Materials use export-safe Principled BSDF base colours and roughness. All roof tiles and marble subdivisions are geometry. There are no external texture, linked-library or add-on dependencies. The native file is explicitly packed.

## Reuse and attribution

Original procedural geometry and deliverable scripts were created for this project. Reference photographs and drawings retain their listed source licenses and authors. Reference metadata and license links are included. Local copyrighted Opera imagery used only for study is excluded from the distributable reference bundle and from native packed assets. The map-based site comparison credits © OpenStreetMap contributors and the Open Database License 1.0. Consult the research records before redistributing reference images.

This is a source-informed visual reconstruction, not a certified measured survey. Do not use it for conservation, engineering, construction documentation or quantity takeoff.
