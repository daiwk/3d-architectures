# Open and inspect the cathedral

## Native Blender file
Open `saint_basil_final_r02.blend` in Blender 4.3 or newer. The final asset uses metres and includes all texture images packed inside the file. No add-on, network connection or external texture path is required to display the model. The nine top-level collections separate references, blockout, structure, reusable modules, details, materials, ground, lights and cameras.

The corrected r02 native persistently includes `Neutral_Day` and `Sunset` scenes. Select either in Blender’s Scene selector. Both light rigs also remain under `07_LIGHTS`. For the already-delivered first edition, the included `scripts/activate_lighting.py` helper creates its missing convenience Sunset scene without changing architecture or saving the original file. Chinese steps are in `README_LIGHTING_CN.md`. Camera names beginning `Inspection_` cover the eight compass views; showcase cameras supply composed exterior views. The material and repeated-window modules remain editable. Some template objects are intentionally hidden, while their linked instances are visible.

## Walk start
Select `Exterior_Walk_Start`, make it the active camera if necessary, and enter camera view. Its eye point is 1.65m above the modeled paving surface. Use Blender’s View → Navigation → Walk Navigation, or Fly Navigation. Common controls are mouse look, WASD movement, Q/E vertical movement, mouse wheel speed adjustment, Enter/left click to confirm and Esc/right click to cancel. Blender keymap settings can change shortcuts.

The asset is exterior only. Stay outside the masonry; no collision system is guaranteed, and entering walls or gallery shadow pockets will not reveal furnished interiors. Paving is level and simplified.

## GLB
`saint_basil_final_r02.glb` is a self-contained glTF 2.0 binary with embedded textures, portable PBR materials and mesh geometry. Lighting/background can look different in different viewers. Navigation and collision are viewer features, not guaranteed by the GLB. The native Blender file is the authoritative editable version.

## Development stages
`versions/` preserves six immutable research, whitebox, structure, details, materials and final milestones. Intermediate stages intentionally show earlier proportions or incomplete decoration. `scripts/` contains the original construction modules, material generation, source-comparison and finalization tools. Read `sources.md`, `assumptions.md` and `final_report.md` before presenting the work as architectural evidence.

The scene is a source-informed reconstruction, not a measured survey or an exact record of every painted detail.
