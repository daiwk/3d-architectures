# Texture attribution

Procedural masonry, paving and normal maps authored from scratch for this model.

Painted panel, porch vertical panel, gallery column and arabesque crops derive from acediscovery, Saint-Basil-Cathedral Moscow, 2019-01-24, CC BY 4.0.
Source: https://commons.wikimedia.org/wiki/File:Saint-Basil-Cathedral_Moscow.jpg
License: https://creativecommons.org/licenses/by/4.0/
Changes: crop, perspective rectification (gallery panel), brightness correction, resampling. Derivative crops remain CC BY 4.0; attribution must travel with public use. No claim of a new invented Russian ornament. Pattern placement is representative of the photographed gallery/porch modules, not a complete fresco survey.
