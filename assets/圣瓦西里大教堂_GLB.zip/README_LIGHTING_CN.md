# 日景与日落灯光

## 修正版 r02
1. 在 Blender 中打开 `saint_basil_final_r02.blend`
2. 在窗口顶部的“场景 / Scene”下拉框选择 `Neutral_Day`（日景）或 `Sunset`（日落）
3. 按数字小键盘0进入当前相机视图；按F12渲染

两个场景在r02中均已持久保存，共用同一建筑模型。纹理已打包，无需联网或安装插件。

## 已下载的第一版
第一版包含 `07_LIGHTS` 下的两套灯光集合和日落相机，但未保留独立的 `Sunset` 场景。不要覆盖原文件。

打开第一版后：切换到“Scripting / 脚本”工作区 → 文本编辑器菜单“Text → Open” → 打开 `scripts/activate_lighting.py` → 点击“Run Script / 运行脚本”（或在文本编辑器按Alt+P）。脚本会创建并切换到日落场景，不会自动保存或覆盖文件。需要保留时请“另存为”新文件。

命令行等价方式：
`blender saint_basil_final.blend --python scripts/activate_lighting.py`

灯光集合位于 `07_LIGHTS`：`Rig_Neutral_Day` 为日景，`Rig_Sunset` 为日落。助手脚本只操作这些现有灯光、相机及天空设置，不改变建筑几何。
