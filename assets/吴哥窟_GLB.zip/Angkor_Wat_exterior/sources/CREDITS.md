# Angkor Wat photographic source credits

Retrieved and license-checked 2026-09-30 on individual Wikimedia Commons file pages. Choose the license below where the source offers multiple licenses. Image dimensions and bytes verified locally. These are ordinary photographic references, not 3D assets.

If redistributing a photo or a photo-derived crop/normal map/relief mesh: retain the named credit, source link and license link; disclose edits. For CC BY-SA images, license the photo-derived asset under that license or a compatible one. A photograph does not license a complete architectural survey, and none is supplied here.

## upper_ne_2012.jpg
- BrightRaven | CC BY 3.0 | 2012-09-01
- Source: https://commons.wikimedia.org/wiki/File:Angkor_Wat_upper_level.JPG
- License: https://creativecommons.org/licenses/by/3.0/
- Original image: https://upload.wikimedia.org/wikipedia/commons/d/dd/Angkor_Wat_upper_level.JPG
- NE upper sanctuary close view; tower tiers, galleries, stairs and moulded podium
- Local original: [3648, 2736] pixels; 2691014 bytes; no edits by research task

## east_2025.png
- Mariam.alshamsi | CC0 1.0 | 2025-01-11
- Source: https://commons.wikimedia.org/wiki/File:Angkor_Wat_East_Gate.png
- License: https://creativecommons.org/publicdomain/zero/1.0/
- Original image: https://upload.wikimedia.org/wikipedia/commons/f/f1/Angkor_Wat_East_Gate.png
- East facade per uploader; modern frontal exterior, also corroborated with geolocated 2023 east view
- Local original: [2698, 1146] pixels; 6527788 bytes; no edits by research task

## aerial_se_2005.jpg
- Charles J Sharp | CC BY 2.5 | 2005-08
- Source: https://commons.wikimedia.org/wiki/File:Angkor-Wat-from-the-air.JPG
- License: https://creativecommons.org/licenses/by/2.5/
- Original image: https://upload.wikimedia.org/wikipedia/commons/5/5d/Angkor-Wat-from-the-air.JPG
- SE aerial of whole moated compound; overview only, central roof detail limited
- Local original: [2272, 1704] pixels; 703608 bytes; no edits by research task

## northeast_2023.jpg
- Alexey Komarov | CC BY-SA 4.0 | 2023-03-24
- Source: https://commons.wikimedia.org/wiki/File:Angkor_Wat_seen_from_North_East_corner_2023-03-24.jpg
- License: https://creativecommons.org/licenses/by-sa/4.0/
- Original image: https://upload.wikimedia.org/wikipedia/commons/0/03/Angkor_Wat_seen_from_North_East_corner_2023-03-24.jpg
- NE diagonal exterior, geolocated; gallery windows/columns, naga and projecting steps
- Local original: [4240, 2832] pixels; 2746963 bytes; no edits by research task

## east_2023.jpg
- Alexey Komarov | CC BY-SA 4.0 | 2023-03-24
- Source: https://commons.wikimedia.org/wiki/File:East_side_of_Angkor_Wat_2023-03-24-1.jpg
- License: https://creativecommons.org/licenses/by-sa/4.0/
- Original image: https://upload.wikimedia.org/wikipedia/commons/d/de/East_side_of_Angkor_Wat_2023-03-24-1.jpg
- East exterior; geolocated camera 13.412568,103.868380
- Local original: [4077, 2718] pixels; 2840213 bytes; no edits by research task

## upper_north_gallery_2023.jpg
- Alexey Komarov | CC BY-SA 4.0 | 2023-03-24
- Source: https://commons.wikimedia.org/wiki/File:Northern_gallery_of_Angkor_Wat_2023-03-24-1.jpg
- License: https://creativecommons.org/licenses/by-sa/4.0/
- Original image: https://upload.wikimedia.org/wikipedia/commons/e/ea/Northern_gallery_of_Angkor_Wat_2023-03-24-1.jpg
- Close upper north gallery wall, variable missing turned stone balusters, carved roof ribbing
- Local original: [4240, 2832] pixels; 2358437 bytes; no edits by research task

## devata_triple_kentdavis_2007.jpg
- Kent Davis (Literary Archaeologist) / Devata.org | CC BY-SA 4.0 | 2007-02-08
- Source: https://commons.wikimedia.org/wiki/File:Angkor_Wat_Level_A1_Inside_006_005_004_Kent_Davis_2007_02_08.jpg
- License: https://creativecommons.org/licenses/by-sa/4.0/
- Original image: https://upload.wikimedia.org/wikipedia/commons/7/74/Angkor_Wat_Level_A1_Inside_006_005_004_Kent_Davis_2007_02_08.jpg
- Three full standing devatas on inside Bakan gallery; location from photographer; uploaded version 2026
- Local original: [2239, 3345] pixels; 3868315 bytes; no edits by research task

## narrative_battle_caulfield_2009.jpg
- Allie Caulfield | CC BY 2.0 | 2009-09-05
- Source: https://commons.wikimedia.org/wiki/File:Angkor_Wat_battle_reliefs_(2009).jpg
- License: https://creativecommons.org/licenses/by/2.0/
- Original image: https://upload.wikimedia.org/wikipedia/commons/6/6c/Angkor_Wat_battle_reliefs_%282009%29.jpg
- Narrative battle relief with soldiers, shields and chariot; precise panel location not verified
- Local original: [4592, 3056] pixels; 13420570 bytes; no edits by research task

## central_tower_gunther_2014.jpg
- Michael Gunther | CC BY-SA 4.0 | 2014-08-12
- Source: https://commons.wikimedia.org/wiki/File:Central_Tower_AngkorWat0767.jpg
- License: https://creativecommons.org/licenses/by-sa/4.0/
- Original image: https://upload.wikimedia.org/wikipedia/commons/2/26/Central_Tower_AngkorWat0767.jpg
- Central tower from SE, incut corners, diminishing storeys, lotus crown; IGNORE false caption saying 60m above upper platform
- Local original: [1944, 2592] pixels; 578571 bytes; no edits by research task

## southeast_2012.jpg
- Gunawan Kartapranata | CC BY-SA 3.0 | 2012-03-21
- Source: https://commons.wikimedia.org/wiki/File:Angkor_Wat_Southeast_View.jpg
- License: https://creativecommons.org/licenses/by-sa/3.0/
- Original image: https://upload.wikimedia.org/wikipedia/commons/1/1d/Angkor_Wat_Southeast_View.jpg
- SE whole temple oblique; south and east flank, low outer gallery, major silhouette
- Local original: [960, 640] pixels; 122981 bytes; no edits by research task

## northwest_2004.jpg
- L-Bit; brightened and sharpened by Rugby471 | CC BY-SA 3.0 | 2004-10-04
- Source: https://commons.wikimedia.org/wiki/File:Angor_Wat_NW_Cnr.jpg
- License: https://creativecommons.org/licenses/by-sa/3.0/
- Original image: https://upload.wikimedia.org/wikipedia/commons/e/e3/Angor_Wat_NW_Cnr.jpg
- NW exterior, north/west flank; photo processing predates download
- Local original: [2042, 1011] pixels; 441869 bytes; no edits by research task

## west_2019.jpg
- Balon Greyjoy | CC0 1.0 | 2019-12-10
- Source: https://commons.wikimedia.org/wiki/File:20191210_Angkor_Wat_from_west-2.jpg
- License: https://creativecommons.org/publicdomain/zero/1.0/
- Original image: https://upload.wikimedia.org/wikipedia/commons/a/a5/20191210_Angkor_Wat_from_west-2.jpg
- WSW pond view (camera west and south of central axis); clear upper silhouette, lower fabric partly tree occluded
- Local original: [5266, 3511] pixels; 10779433 bytes; no edits by research task

## aerial_jurvetson_2007.jpg
- Steve Jurvetson | CC BY 2.0 | 2007-12-25
- Source: https://commons.wikimedia.org/wiki/File:Angkor_Wat_aerial_view.jpg
- License: https://creativecommons.org/licenses/by/2.0/
- Original image: https://upload.wikimedia.org/wikipedia/commons/8/8f/Angkor_Wat_aerial_view.jpg
- High-angle south overview inferred from west causeway at image left; roof topology and actual long approach
- Local original: [4328, 2212] pixels; 5153805 bytes; no edits by research task

## west_gopura_2014.jpg
- PIERRE ANDRE LECLERCQ | CC BY-SA 4.0 | 2014-01-29
- Source: https://commons.wikimedia.org/wiki/File:Angkor_Wat_western_gopura_of_the_outer_wall.jpg
- License: https://creativecommons.org/licenses/by-sa/4.0/
- Original image: https://upload.wikimedia.org/wikipedia/commons/4/4b/Angkor_Wat_western_gopura_of_the_outer_wall.jpg
- Close oblique enclosure-IV western gopura, truncated tower, gallery/half-roof and openings; not central temple
- Local original: [4712, 2930] pixels; 2820346 bytes; no edits by research task

## lintel_lumoplank_2024.jpg
- lumoplank | CC0 1.0 | before 2024-02-24
- Source: https://commons.wikimedia.org/wiki/File:Angkor_Wat,_details_-_Angkor1151.jpg
- License: https://creativecommons.org/publicdomain/zero/1.0/
- Original image: https://upload.wikimedia.org/wikipedia/commons/e/e6/Angkor_Wat%2C_details_-_Angkor1151.jpg
- Carved lintel over portal with framing and nearby stone texture; uploader date is latest possible not exact exposure
- Local original: [3766, 5021] pixels; 15866236 bytes; no edits by research task

## west_axial_causeway_2006.jpg
- Gisling / 唐戈 | CC BY-SA 3.0 | 2006-11
- Source: https://commons.wikimedia.org/wiki/File:Angkor_Wat_from_causeway.jpg
- License: https://creativecommons.org/licenses/by-sa/3.0/
- Original image: https://upload.wikimedia.org/wikipedia/commons/0/06/Angkor_Wat_from_causeway.jpg
- True west-to-east axial causeway view; camera heading90 degrees per Commons; older stone paving reference
- Local original: [800, 528] pixels; 88255 bytes; no edits by research task

## west_full_2014.jpg
- LBM1948 | CC BY-SA 4.0 | 2014-12-09
- Source: https://commons.wikimedia.org/wiki/File:Angkor_Wat,_vista_general_2.jpg
- License: https://creativecommons.org/licenses/by-sa/4.0/
- Original image: https://upload.wikimedia.org/wikipedia/commons/4/42/Angkor_Wat%2C_vista_general_2.jpg
- West oblique exterior per photographer; strong layered gallery/tower silhouette
- Local original: [4100, 2644] pixels; 7596434 bytes; no edits by research task
