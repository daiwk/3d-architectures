# Angkor Wat exterior: dimensional decisions and limits

Research checked 30 September 2026. This is an editable, source-informed architectural visualization of surviving exterior forms. It is not a laser scan, conservation survey, complete archaeological reconstruction or exact date-stamped record of every repair. One Blender unit equals1 metre. X east, Y north, Z up; the west approach is negative X.

## Included scope
Central temple and directly connected galleries; three principal platform/court levels; western cross-cloister; four connected-court library forms; five upper quincunx towers; the cruciform Grand Terrace; the full internal processional avenue; enclosure-IV western entrance colonnade with truncated gate masses and elephant passages; the western moat bridge and apron. The archaeological park, full perimeter wall, the complete moat and detached outer libraries are not modeled. A cropped western water strip, two reflecting basins, maintained grass and six fan palms provide restrained context.

## Dimensional anchors
- Outer gallery control rectangle215 m E–W ×187 m N–S; intermediate115 × 100 m, following Glaize and Fletcher et al. 2015
- Upper gallery control group≈60 m square (Glaize); broader first-enclosure/podium envelope≈75 m (Fletcher etal.). These describe different boundaries
- Lower/intermediate rectangles extend westward. Working limits are approximately[-121.5,+93.5] and[-65,+50]m inX; north/south cardinal doors follow the sanctuary axis
- Central summit≈65 m, following APSARA. The four corner apices are modeled at48 m from photographic comparison, not a surveyed figure
- Corner tower centers are(±30,±30)m. Main court levels+4,+10,+23 m form the working height grid. These are coherent approximations, not four certified survey elevations
- West-gate porch X−542 m; Grand Terrace west edge X −196 m, from an inspected reproduction of Stencel/Gifford/Morón’s 1976 measurement table. Their346 m separation matches Glaize’s rounded350 m avenue. G4W center X −550 m is inferred from its projecting porch
- West entrance colonnade235 m; western moat bridge200 × 12 m. The inner avenue is9.4 m overall and1.5 m above adjacent lawn

## Height datum caution
Glaize reports a42 m central tower, a62 m summit above the main causeway, and a25 m excavation to external ground with a deposit at23 m. APSARA says approximately65 m high without giving the same benchmark. The English Glaize translation contains an inconsistent30 m Bakan-substructure statement. No fabricated3m causeway conversion is used. The+23 m upper floor is a documented production approximation, supported but not precisely proven by excavation descriptions;23–25 m remains plausible.

## Geometry and ornament
Gallery bay counts, portal projections, tier-specific cornice dimensions, exact stair risers and individual blocks are photo-informed approximations. The upper platform was widened within the≈75 m envelope to physically support all tower bases. Gallery doors are actual openings, not dark painted rectangles.

Tower forms use re-entrant cruciform profiles, four diminishing storeys, three lotus crown ranks, shaped antefixes and source-derived shallow relief. They are simplified at close inspection. The representative devata, narrative and lintel modules preserve licensed photographic iconography; their depth is an illustrative reconstruction from source luminance and broad sculptural masks, not photogrammetry. Repeated modules do not claim the original distribution or a complete narrative inventory. No random invented religious scenes, generated fake carvings or complete downloaded 3D models were used.

Surviving truncated middle/gallery gateway towers remain truncated. Current restored second-court library masses are included. Temporary scaffolding, current visitor barriers and modern access stair overlays are omitted; their precise late 2026 state was not established. No full interior route or collision mesh is provided.

## Environment and export
The terrain has real openings below the water surfaces; ground-founded architecture sits on the Z0 surface. The broad surrounding lawn terrace is modeled at +0.25 m, a photo-informed contextual assumption; no retrieved source fixes its elevation. The lower gallery remains at +4 m, with the moulded base extended down to meet that terrace. Lawn treatment outside the paved core is contextual. Procedural warm sandstone has varied joints and limited damp/mossy low courses; it is not intended as exact block-by-block condition mapping.

GLB preserves visible geometry and embedded material textures. Blender node lighting, the Nishita sky and the camera-orbit action remain native-file features; appearance in third-party GLB viewers depends on their lighting. Photographic reference images are compacted in portable native copies, with originals and full credits supplied separately. Immutable authoring checkpoints remain preserved independently.
