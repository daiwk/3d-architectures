# Mogao exterior study: opening and walking

Open the final standalone Blender file. Units are metres. +X is north, +Y is west into the cliff; the pavilion faces east toward -Y.

Select the Neutral_Day or Sunset scene. Each has a persistent independent light rig. The file opens with a front-oblique exterior camera and the entire scene visible. No third-party texture paths or linked libraries are needed.

For a pedestrian view choose Exterior_Walk_Start in the camera selector. Its camera origin is exactly1.65m over the actual plaza surface, verified by downward raycast. Use Blender viewport Walk Navigation (Shift+grave-accent), then WASD and mouse. Esc cancels the navigation change; left click confirms it. Speed and collision behavior depend on your Blender navigation preferences.

This is an exterior visual model, not a collision-safe simulator. Do not interpret an ability to move through geometry as a real accessible route. There are no reconstructed cave interiors. Portal backs are intentionally closed and dark.

The source scripts and parameters are included for repeatable changes. The nine top-level collections separate reference datum, blockout, structure, modules, details, materials, ground, lights and cameras. The native versions preserve research, blockout, corrected blockout, structure, details, materials and final stages.

The GLB is a convenient embedded preview of geometry, material colors and vertex colors. Native Blender retains fine procedural surface bump, scene light-rig controls and editing scripts. GLB viewers may apply different tone mapping and lighting.

Inspection cameras cover front, back, both sides and four diagonals. Rear and side views intentionally reveal the limits of a bounded terrain study; unseen rear architecture has not been invented. The20-second movie is a real rendered frontal orbit arc, keeping the externally visible monument in view because the cliff naturally occludes it from the west.
