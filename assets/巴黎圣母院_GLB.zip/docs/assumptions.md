# Assumptions and limits

## Dated state and scope
The intended state is the permanent restored exterior documented in October 2025. It is not the exact December 2024 reopening-day site. The returned spire figures and completed spire cladding are included; temporary scaffolding, cranes, crowds and surrounding Paris blocks are excluded. The low south-side sacristy/treasury annex is included because it materially affects the river-side silhouette. No cathedral interior is reconstructed. Simple dark inset occlusion proxies behind the real belfry openings suppress unrealistic through-sky views; they are not a measured reconstruction of the internal bell frames.

## Metric controls
The model uses metres, with local +X from the west front toward the apse, +Y north and Z up. The general primary controls are 127 m church length, 48 m transept width, 43.5 m west facade width, 69 m tower parapets and 96 m spire tip. Decorative stair caps can rise above the quoted tower-parapet datum.

The north/south tower widths follow the Ministry's 14.91/13.69 m figures. The approximately 20.5 m lower western block depth comes from plan fitting. The upper belfries are near-square, with depths inferred from their widths and the official square-tower description, not separately surveyed measurements. Allow approximately ±1 m uncertainty in this inferred depth.

The crossing at about X=67 m and apse centre at about X=104 m are plan-fitted estimates, generally ±1–2 m. The roof ridge is modelled at 43 m; published “under roof” dimensions do not define a surveyed external lead-ridge height, so allow roughly ±1 m. Facade storeys and local mouldings are fitted from images, not measured to centimetres.

The spire socket/open-stage levels near 47/54/60 m and the long needle to the 96 m tip follow the inspected 4 October 2025 photograph; local levels have roughly ±1.5 m uncertainty. The internal 30 m-deep structural assembly is not modelled as an interior.

## Structural topology
Ten interior nave bays include the first two beneath the west towers. There are seven principal exterior nave flyer planes on each side. The choir has four straight primary flyer planes per side and six principal radial chevet supports. The high apse has five facets; the outer chapel wall has additional subdivisions. The six radial supports do not include an invented central axial flyer.

Historic plans show five rectilinear choir slots, whereas a current Cathedral description says four. The visible plan controls the model geometry, and the terminology discrepancy is retained in the sources rather than concealed. The model's physical contact audit verifies mesh contact at both ends of the 28 primary flyers; it does not establish real-world structural adequacy.

## Sculpture and fine detail
Major freestanding figures are authored draped meshes with shaped heads, arms, hands and robes. They are interpretive architectural-scale sculptures, not exact reproductions of every individual medieval or 19th-century portrait. Grotesques, evangelist symbols, capitals and small crockets are similarly simplified in geometry.

The west rose preserves the source's 12 inner and 24 outer foiled-sector hierarchy. The north/south transept rose constructions are differentiated by their 16/12 primary divisions. Fine leadwork and every stained-glass scene are not reproduced.

Licensed photographic portal reliefs and drapery detail supplement the shaped geometry. The portal relief's shallow mesh variation is illustrative, with a maximum around 0.065 m; luminance-derived relief is not a measured depth scan. Photographic baked shading and limited source resolution remain visible on close inspection. Face placement is not fabricated by projecting an unrelated face onto a sculpture.

## Authorship and provenance
The scene is generated from Blender factory-empty settings by the supplied scripts. No rejected previous model or complete online 3D model was loaded or reused. Source photographs and public-domain drawings were used as references and licensed surface-detail inputs. Original historical pictures are not used to imply that old weathering, green patina or temporary works match October 2025.

## Navigation and exchange
The supplied walking viewpoint and exterior route are kept clear of the ground and building. This is a Blender architectural inspection scene, not an interior simulation or game collision engine. The GLB is a portable textured exchange file; its viewer lighting may differ from the native Cycles renders.
