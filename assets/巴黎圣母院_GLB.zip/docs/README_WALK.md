# Open and inspect the reconstruction

## Native Blender scene
Open `NotreDame_Paris_Restored_2025.blend` in Blender 4.3 or newer. All used image textures are packed. The working unit is one metre. The cathedral's west-to-east axis is local +X; local +Y is north. These are building axes, not a georeferenced northing/easting system.

The nine named collections are:

- 00_REFERENCE: source controls and attribution pointers
- 01_BLOCKOUT: overall dimensional reference; the full whitebox is preserved in v02
- 02_STRUCTURE: primary walls, roofs and load-bearing supports
- 03_MODULES: editable repeated architectural components
- 04_DETAILS: sculptural, tracery, roof and relief detail
- 05_MATERIALS: packed material library information
- 06_GROUND: simple forecourt and ground only
- 07_LIGHTS: independently switchable DAY and GOLDEN sun rigs
- 08_CAMERAS: inspection, photograph-fit, final, orbit and walking cameras

Repeated components share Mesh data. Moving an object does not move every instance; editing its mesh changes the linked instances. Make an object single-user first if you want a one-off change. The reconstruction scripts remain the authoritative reproducible source.

## Walking viewpoint
Select `WALK_1.65m` and view through the camera. Its starting point is in the forecourt at 1.65 m above the ground, clear of the building. The hidden `WALK_route_1.65m_hidden` curve and the scene's route-point data describe an exterior circuit.

For interactive navigation in Blender, use View → Navigation → Walk Navigation (normally Shift + the accent-grave key; shortcuts can vary with keymap). Move with WASD and look with the mouse. Escape cancels; confirm to keep the viewpoint. The saved camera eye height is 1.65 m. Blender’s interactive walking preferences are application settings, so choose that view height there if using gravity-based walk navigation. The clear exterior guide is intended for inspection, not a playable interior or a game-style collision system. Arbitrary free movement can still pass through geometry.

The package includes no interior reconstruction. Stay on the exterior guide rather than walking through portals or walls.

## Cameras and lighting
`INSPECT_01_West` through `INSPECT_09_Top` are orthographic inspection cameras. `PHOTO_MATCH_*` are approximate source-landmark perspective fits; their source and residual error are stored as custom properties. A photo match is not a photogrammetric survey.

`DAY key` and `GOLDEN key` are two alternative lighting rigs. Enable one at a time in render visibility. The golden-hour showcase is an artistic lighting condition, not a reconstruction of the lighting in a dated source photograph.

`ORBIT_20seconds` is animated for a full exterior revolution. The delivered movie is rendered from actual changing camera poses at 12 fps, not a montage of still images.

## GLB
The GLB includes geometry, embedded image textures, cameras and orbit animation. It has no external texture-file dependency. Viewer lighting and colour management can differ from the Blender Cycles stills. Blender is the editable master.

## Scope and accuracy
Use `sources.md`, `assumptions.md`, `texture_licenses.md`, and `final_report.md` together. Published primary dimensions anchor the reconstruction. Several local dimensions and detailed sculptures are visual approximations. It is not a measured conservation model, a structural-engineering assessment, or a complete sculpture scan.
