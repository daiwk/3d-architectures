# Texture and photographic derivative credits

Keep this file and texture_derivatives.json with the textured scene and renders. The JSON lists every photographic derivative, its exact source, author, date, licence, crop rectangle, output size, changes and SHA-256. No photograph-derived texture is left unattributed.

## Procedural materials

Limestone courses, limestone normal, carved limestone, restored lead and forecourt paving were authored procedurally for this model. They are offered under CC0-1.0. See textures/procedural_texture_manifest.json and the deterministic generator.

## Photographic sources and their uses

- Uoaei1, 2015-10-10: [last_judgment_tympanum_2015-10-10_Uoaei1_CC-BY-SA4.jpg](https://commons.wikimedia.org/wiki/File:Paris_Notre-Dame_Portail_du_Jugement_Dernier_Tympanon_01.JPG). [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/).
- Carlos Delgado, 2012-02-17: [west_front_2012_CarlosDelgado_CC_BY_SA_3.jpg](https://commons.wikimedia.org/wiki/File:Cath%C3%A9drale_Notre-Dame_de_Paris_-_12.jpg). [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/).
- Uoaei1, 2015-10-10: [virgin_jamb_2015-10-10_Uoaei1_CC-BY-SA4.jpg](https://commons.wikimedia.org/wiki/File:Paris_Notre-Dame_Portail_de_la_Vierge_%C3%89brasement_01.JPG). [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/).

### Portal tympana

judgment_relief_*, virgin_relief_* and anne_relief_* include colour, normal and height inputs. Crops are rescaled and recoloured to restrained limestone. Luminance-derived normals and smoothed shallow displacement are illustrative, not measured depths. The final shallow mesh variation is limited to approximately0.065m. Major freestanding figures remain independently authored3D geometry.

### Archivolt strips

judgment_archivolt_*, virgin_archivolt_* and anne_archivolt_* are separate derivatives with colour and normal images. They are cropped/rescaled, limestone-recoloured and projected onto physically extruded stepped arch orders. Their crop rectangles and exact sources are listed individually in texture_derivatives.json.

### Drapery maps

sculpture_drapery_0.jpg and sculpture_drapery_1.jpg derive from Uoaei1’s Virgin portal jamb photograph dated10October2015, CC BY-SA4.0. They are cropped, resized to256×1024, desaturated/recoloured and projected onto selected forward-facing figure surfaces below the neck, primarily robes. Face/head polygons are excluded. The model does not claim to reproduce those saints or exact poses.

## Distribution terms

The photographic texture adaptations and the distributed textured scene/render derivatives are shared under [CC BY-SA4.0](https://creativecommons.org/licenses/by-sa/4.0/). Original photographs retain their stated original licences, including Carlos Delgado’s [CC BY-SA3.0](https://creativecommons.org/licenses/by-sa/3.0/) source. Preserve credit, source, licence and changes statements when redistributing.

The source/model/overlay sheets are adapted photographic comparisons; each credits its photographer, date and source licence, with exact URLs in photographic_assets.json. No unlicensed official-site photograph is redistributed.
