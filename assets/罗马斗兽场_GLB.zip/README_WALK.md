# Colosseum — current ruin exterior

## Open and explore
Extract the logical ZIP packages into the same project directory, allowing their `versions`, `textures`, `inspection`, `showcases`, `scripts` and `qa` folders to merge.

1. Open `versions/v06_final.blend` in Blender 4.3 or newer. Geometry uses metres: one Blender unit is one metre.
2. In the Outliner, expand `08_CAMERAS` and select `Exterior_Walk_Start`.
3. Make it the active camera with Ctrl+Numpad0. Press Numpad0 to enter the camera view if necessary. The start is on the western Valadier entrance approach, approximately 1.65 m above the raycast-confirmed ground, facing the monument. The official standard-entry page locates access by Sperone Valadier near the Arch of Constantine: https://colosseo.it/biglietti/colosseo-foro-romano-palatino/ . The exact modeled gate coordinates remain approximate.
4. With the pointer over the 3D viewport, press Shift+grave accent (`~`) for Walk Navigation. Alternatively use View → Navigation → Walk Navigation or search for “Walk Navigation” with F3.
5. Move with W/A/S/D, look with the mouse, and use Q/E to move down/up. Mouse wheel adjusts speed. Left click/Enter confirms the view; right click/Esc exits without committing the move. Keyboard mapping can differ with custom Blender keymaps.

There is no collision system or complete interior visitor route. Turn off Walk Navigation gravity if it drops the view unexpectedly. Geometry behind the exterior consists of visible ring walls and support fragments, not a finished navigable interior. This is a Blender architectural model, not a game engine project; frame rate is not guaranteed.

## Navigation and render cameras
- Eight `Inspection_…` cameras cover the local south, north, west, east and four diagonal directions. These labels refer to the monument-local axes approximately corresponding to those compass directions, not to a surveyed geographic camera position.
- Four `Showcase_…` cameras are included for longer views and an arcade study.
- `Exterior_Walk_Start` was checked with a downward ground ray and a 2 m forward clearance ray. See `qa/walk_start_validation.json` and its rendered start image.
- Local X is the major ellipse axis, approximately WNW–ESE; local +Y is the preserved northern side. No geodetic registration is claimed.

## Editing
The required collections are `00_REFERENCE`, `01_BLOCKOUT`, `02_STRUCTURE`, `03_MODULES`, `04_DETAILS`, `05_MATERIALS`, `06_GROUND`, `07_LIGHTS`, `08_CAMERAS`.

`03_MODULES` contains hidden, named arch, voussoir and architectural-order masters. Many instances share mesh datablocks. Unhide a master in the Outliner and edit its mesh to change all linked instances; use Object → Relations → Make Single User → Object & Data for an independent local edit. Hidden blockout/master objects are deliberately excluded from the GLB.

Editable source scripts in `scripts/` place modules by an equal-arc-length ellipse lookup, with explicit ring radii, heights, opening dimensions, preserved bay lists and support positions. The scene custom properties record key dimensions. The historical plan is more complex than a perfect ellipse; this is an architectural approximation.

The original overall ellipse target is 189 × 156 m and the highest surviving facade is 48.5 m. Buttresses, moldings and engaged columns project beyond the nominal ellipse. Because the southern outer facade is absent, the rendered building bounding box is not the original complete ellipse.

## Lighting and materials
In `07_LIGHTS`, the default neutral-day rig uses `Neutral_Day_Sun`; `Golden_Hour_Sun` is disabled for rendering. To use the warm rig, disable the day sun, enable the golden sun, and set World Background strength to about 0.28 (day: 0.55). The two golden showcases use that configuration.

Original generated base-color textures are packed in the Blender file and embedded in the GLB. Separate PNGs are in `textures/`. They are CC0 assets created for this model. Shader noise/bump parameters remain editable. The portable GLB retains base color/roughness; Blender-specific procedural micro-bump is not reproduced exactly by every viewer.

## Versions and scope
Six separate snapshots preserve research, blockout, structure, details, materials and final state. Earlier versions intentionally contain the issues corrected in the documented comparison cycles. Use `v06_final.blend` for delivery.

This depicts the present permanent ruin, including the missing southern outer galleries, different Stern/Valadier buttresses, an exposed two-tier inner ring, and the March 2026 southern paving concept. It is not an intact ancient reconstruction, conservation survey or metrically certified replica. Temporary scaffolding, visitors, traffic, surrounding city, elaborate vegetation, hypogeum and a complete seating-bowl/interior route are outside scope. Read `sources.md` and `assumptions.md` for evidence and limitations.

## Rebuilding from the included scripts
The scripts resolve the project root from their own location; optionally set `COLOSSEUM_ROOT` to another project folder. Run with Blender's background Python entry point. The canonical build order is `build_colosseum.py`, `build_structure.py`, `build_details.py`, `build_materials.py`, `finalize.py`, `refine_ruin_edges.py`, then `fix_support_contacts.py`. The last step is required for the final connected supports.

`render_delivery.py -- inspection` and `-- showcases` produce the final view sets. `render_orbit_final.py` produces the corrected Cycles orbit frames, and `encode_orbit.sh` encodes the video with FFmpeg. Historical diagnostic and rejected Workbench scripts are retained for transparency; they are not the final orbit workflow.

Scene/master custom properties record construction inputs rather than functioning as live Geometry Nodes controls. Change the explicit Python dimensions/bay lists and regenerate for a new plan; editing a shared master mesh immediately updates linked copies.
